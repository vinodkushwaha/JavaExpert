package com.mindtree.program.interview.BoxingAndUnBoxing;

/*While overloading methods in Java you may come across such a situation where 
one signature takes wrapper reference type as formal 
argument and another signature takes a wider formal argument. For example, aMethod(Integer x)
and aMethod(long x). Here, Integer is a wrapper reference type. If you call overloaded
aMethod with an int argument, which method do you think will be called? The answer
		is that the compiler will choose widening over boxing,
		so the output will be long version: 5 of the following piece of code:*/
class BoxingWideningDemo
{
  public static void main (String[] args)
  {
    int l = 5;
    aMethod(l);
    //int--> long--> float--> double --> Integer
  }
 
  static void aMethod (Integer x)
  {
    System.out.println("int version: " + x);
  }

 /* static void aMethod (long x)
  {
    System.out.println("long version: " + x);
  }*/
  //long version: 5

  static void aMethod (double x)
  {
    System.out.println("double version: " + x);
  }
  //double version: 5.0
 
 static void aMethod (float x)
  {
    System.out.println("float version: " + x);
  }
  //float version: 5.0

  
  //didin't work
/*  static void aMethod (char x)
  {
    System.out.println("char version: " + x);
  }*/
  //int version: 5
 /*   static void aMethod (byte x)
  {
    System.out.println("byte version: " + x);
  }*/
  
   //int version: 5
  
 
}


