package com.mindtree.priorityQueue;

import java.util.PriorityQueue;

public class MinHeap_PQ {
	PriorityQueue<Integer> pq;

	public MinHeap_PQ() {
		pq = new PriorityQueue<Integer>();
	}

	public void insert(int[] x) {
		for (int i = 0; i < x.length; i++) {
			pq.offer(x[i]);
		}
	}

	public int peek() {
		return pq.peek();
	}

	public int extractMin() {
		return pq.poll();
	}

	public int getSize() {
		return pq.size();
	}

	public void print() {
		System.out.println(pq);
	}

	public static void main(String[] args) {
		int[] arrA = { 1, 6, 2, 9, 4, 3, 8 };
		MinHeap_PQ i = new MinHeap_PQ();
		i.insert(arrA);
		i.print();
		System.out.println("Min Element in the Priority Queue: "
				+ i.extractMin());
		System.out.println("Min Element in the Priority Queue: "
				+ i.extractMin());
		System.out.println("Min Element in the Priority Queue: "
				+ i.extractMin());
		System.out.println("Priority Queue Size: " + i.getSize());
	}
}

