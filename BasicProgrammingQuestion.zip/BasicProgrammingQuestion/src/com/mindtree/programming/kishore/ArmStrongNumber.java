package com.mindtree.programming.kishore;

public class ArmStrongNumber {

	public static void main(String[] args) {
		int num = 153;
		int sum = 0;
		int tmp = num;
		while (num > 0) {
			int d = num % 10; //3,5,1
			System.out.println("d::" + d);
			sum += d * d * d;
			num = num / 10; // 15 , 1, 0
			System.out.println("num:" +num);
		}
		 if(tmp==sum){
			 System.out.println("Number is Armstrong ");
		 }else
			 System.out.println("Number is Not Armstrong ");

	}

}
