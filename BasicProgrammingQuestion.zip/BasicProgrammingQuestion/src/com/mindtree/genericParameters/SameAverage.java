package com.mindtree.genericParameters;

//What will be the output?

public class SameAverage {
    public static void main(String args[])
    {
        Integer[] integerNumbers = {1, 2, 3, 4};
        Double[] doubleNumbers = {1.0, 2.0, 3.0, 4.0};
        Average<Integer> integerObject = new Average<Integer>(integerNumbers);
        Average<Double> doubleObject = new Average<Double>(doubleNumbers);
        System.out.println(integerObject.sameAverage(doubleObject));
    }
}
class Average<T extends Number>
{
    T[] numbers;
    Average(T[] numbers)
    {
        this.numbers = numbers;
    }
    double getAverage()
    {
        double sum = 0.0;
        for (int i = 0; i < numbers.length; i++) {
            sum += numbers[i].doubleValue();
        }
        return sum / numbers.length;
    }
    boolean sameAverage(Average<T> obj)
    {
        if(getAverage() == obj.getAverage())
        {
            return true;
        }
        return false;
    }
}
