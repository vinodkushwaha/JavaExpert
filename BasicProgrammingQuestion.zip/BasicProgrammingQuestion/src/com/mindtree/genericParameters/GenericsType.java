package com.mindtree.genericParameters;


//Is program compiles or not?

public class GenericsType<MC> {
    private MC t;
    public MC get() {
        return this.t;
    }
    public void set(MC t1) {
        this.t = t1;
    }
    public static void main(String args[]) {
        GenericsType<String> type = new GenericsType<String>();
        type.set("Merit");
        type.set("Merit List");
        GenericsType type1 = new GenericsType(); // LINE A
        type1.set("Campus");
        type1.set(10); // LINE B
        System.out.println(type.get());
        System.out.println(type1.get());
    }
}