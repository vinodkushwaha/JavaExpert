package com.mindtree.genericParameters;

//What will be the output of the following program?

public class IsIn {
    static <T, V extends T> boolean isIn(T x, V[] y)
    {
        for (int i = 0; i < y.length; i++) {
            if(x.equals(y[i]))
                 return true;
        }
        return false;
    }
    public static void main(String args[])
    {
        Integer integerNumber[] = {1, 2, 5, 7};
        if(isIn(5, integerNumber))
        {
            System.out.println("5 is present in the given integer array");
        }
        else
        {
            System.out.println("5 is not present in the given integer array");
        }
        String str[] = {"M", "ER", "IT"};
        if(isIn("IT", str))
        {
            System.out.println("IT is present in the given string array");
        }
        else
        {
            System.out.println("IT is not present in the given string array");
        }

    }
}
