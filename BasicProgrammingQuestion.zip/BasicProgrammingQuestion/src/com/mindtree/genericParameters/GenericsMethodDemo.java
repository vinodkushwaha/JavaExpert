package com.mindtree.genericParameters;


//What will be the output of the following program?

public class GenericsMethodDemo {
    public static <E> void printArray(E[] elements) {  
        for ( E element : elements){          
            System.out.print(element +" ");
        }  
    }  
  
    public static void main( String args[] ) {  
        Character[] charArray = { 'M', 'E', 'R', 'I', 'T','C','A','M','P','U', 'S'};  
        printArray( charArray );   
    }   
}