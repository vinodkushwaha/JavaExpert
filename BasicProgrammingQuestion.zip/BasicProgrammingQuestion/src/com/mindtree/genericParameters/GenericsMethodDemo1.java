package com.mindtree.genericParameters;


//What will be the output of the following program?

public class GenericsMethodDemo1 {
    public static void main(String args[]) {
        String str = "Merit Campus";
        printString(10);
        printString(str);
    }
    
    //Scenario1
    public static <E> void printString(Integer str) {
        System.out.println("Inreger = " + str);
    }
    public static <E> void printString(E str) {
        System.out.println("String = " + str);
    }
    
    //Scenario2
    /*   public static <E> void printString(Integer str) {
        System.out.println("Inreger = " + str);
    }*/
    
      /*    String = 10
    		String = Merit Campus*/
  
}