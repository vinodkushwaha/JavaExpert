package com.mindtree.genericParameters;

//What will be the output of the following program?

public class GenericsLowerBoundedWildCardDemo1 {
	public static void main(String args[]) {
		PrintClassNameHelper<Rectangle> rectangleClass = new PrintClassNameHelper<Rectangle>(new Rectangle());
		print(rectangleClass);
		
/*	
 *       ?  == is a
 *   	List<? super Integer> foo3 = new ArrayList<Integer>();  // Integer is a "superclass" of Integer (in this context)
		List<? super Integer> foo3 = new ArrayList<Number>();   // Number is a superclass of Integer
		List<? super Integer> foo3 = new ArrayList<Object>();   // Object is a superclass of Integer
		
		List<? extends Number> foo3 = new ArrayList<Number>();  // Number "extends" Number (in this context)
		List<? extends Number> foo3 = new ArrayList<Integer>(); // Integer extends Number
		List<? extends Number> foo3 = new ArrayList<Double>();  // Double extends Number

*/
		/* PrintClassNameHelper<Square> squareClass = new PrintClassNameHelper<Square>(new Square());
	        print1(squareClass);*/
	        
	        PrintClassNameHelper<Shape> shapeClass = new PrintClassNameHelper<Shape>(new Shape());
	        print(shapeClass);   
	}

	static void print(PrintClassNameHelper<? super Rectangle> printName) {
		printName.print();
	}
	
	/*static void print1(PrintClassNameHelper<? super Square> printName) {
		printName.print();
	}*/
}

class Shape {
	void printName() {
		System.out.println("This is shape class");
	}
}

class Rectangle extends Shape {
	@Override
	void printName() {
		System.out.println("This is Rectangle class");
	}
}

class Square extends Rectangle {
	void printName() {
		System.out.println("This is Square class");
	}
}

class PrintClassNameHelper<T extends Shape> {
	T shape;

	PrintClassNameHelper(T shape) {
		this.shape = shape;
	}

	void print() {
		shape.printName();
	}
}
