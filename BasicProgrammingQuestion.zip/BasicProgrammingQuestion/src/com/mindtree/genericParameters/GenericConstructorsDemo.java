package com.mindtree.genericParameters;

//What will be the output of the following program?

public class GenericConstructorsDemo {
    public static void main(String args[])
    {
        Gen obj = new Gen(100);
        obj.print();
    }
}
class Gen
{
    private double value;
    <T extends Number> Gen(T value)
    {
        this.value = value.doubleValue();
    	//this.value = value; //cannot convert T to double
    }
    void print()
    {
        System.out.println(value);
    }
}