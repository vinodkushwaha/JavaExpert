package com.mindtree.genericParameters;

import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

//What will be the output of the following program?

public class BoundedWildCardDemo {

	public static void showXY(Coordinates<?> c) {
		System.out.println("X Y Coordinates :");
//c.coords.length give row count
		for (int i = 0; i < c.coords.length; i++) {
			System.out.println(c.coords[i].x + "    " + c.coords[i].y);
		}
	}

	public static void main(String arg[]) {
		Set<? super TreeMap> map = new LinkedHashSet<Map>();
		TwoD twoD[] = { new TwoD(1, 1), new TwoD(7, 9), new TwoD(18, 4) };
		Coordinates<TwoD> twoDCoord = new Coordinates<TwoD>(twoD);
		showXY(twoDCoord);
	}
}

class TwoD {
	int x, y;

	public TwoD(int x, int y) {
		this.x = x;
		this.y = y;
	}
}

class Coordinates<T extends TwoD> {
	T[] coords;

	Coordinates(T[] coords) {
		this.coords = coords;
	}
}