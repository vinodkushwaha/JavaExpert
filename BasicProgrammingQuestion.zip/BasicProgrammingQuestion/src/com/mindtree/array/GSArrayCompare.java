package com.mindtree.array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Java program to find common elements between two arrays in java
 * 
 * @author javamakeuse for(i;i<x;i++){ for(y;y<x;y++){ //code } } is n^2
 * 
 *         but would:
 * 
 *         for(i;i<x;i++){ //code } for(y;y<x;y++){ //code } be n+n?
 */
public class GSArrayCompare {
	public static void compareArray(Integer[] array1, Integer[] array2) {

		for (int i = 0; i < array1.length; i++) {
			for (int j = 0; j < array2.length; j++) {
				if (array1[i] == array2[j]) {
					System.out.println(array1[i]);
				}
			}
		}
	}

	public static void compareArray2(Integer[] array1, Integer[] array2) {

		List<Integer> list1 = Arrays.asList(array1);
		List<Integer> list2 = Arrays.asList(array2);
		List<Integer> list3 = new ArrayList<>(list1);
		list3.retainAll(list2);
		System.out.println("list3 " + list3);
	}

	public static void main(String[] args) {
		Integer[] array1 = { 1, 2, 3, 4, 5, 6 };
		Integer[] array2 = { 8, 1, 3, 9, 4, 5 };
		compareArray(array1, array2);
		compareArray2(array1, array2);
	}
}
