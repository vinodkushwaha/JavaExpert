package com.mindtree.array;

/*Input : arr[] = {1, 2, 3, 4}
Output : 3
Since all elements are different, 
we need to perform at-least three
operations to make them same. For
example, we can make them all 1
by doing three subtractions. Or make
them all 3 by doing three additions.

Input : arr[] = {1, 1, 1, 1}
Output : 0*/

public class MakeAllEqualMinOperation {
	
	
	
	public static void main(String [] arg){
		
		//int [] a={1,2,3};  //3
		
		int [] a={4,3,4}; //2
		int smallest =a[0];
		int sum=0;
		for(int i=0; i<a.length ; i++){
			if(a[i] < smallest){
				smallest = a[i];
			}
			sum+=a[i];
		}
		int minimumOpertion = sum - smallest*a.length;
	
		System.out.println("MInimum Operation:::" + minimumOpertion);
	}

}
