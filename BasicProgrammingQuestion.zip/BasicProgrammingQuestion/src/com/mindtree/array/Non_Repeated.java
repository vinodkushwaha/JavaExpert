package com.mindtree.array;

public class Non_Repeated {
	public static void main(String[] args) {
		int n, flag = 0, count = 0;
		
		int a[] = { 2, 1, 2, 3, 4, 2, 15, 1, 5, 6, 4 };

		n = a.length;
		//System.out.print("Non repeated elements are:");
				for (int i = 0; i < n; i++) 
				{
							for (int j = 0; j < n; j++)
							{
									if (i != j) {
										if (a[i] != a[j]) {// not equal element
											flag = 1;
										} else {
											flag = 0;
											break;
										}
									}
							}
							
						 if (flag == 1)
						     {
								count++;
								System.out.print(a[i] + " ");
								//break;
							 }
				}
		System.out.println("");
		System.out.println("first Number of non repeated elements are:" + count);
	}
}