package com.mindtree.tree;
//Time Complexity: O(n) (Please see our post Tree Traversal for details)
public class MaxDepthBinaryTree {
	Node root;

	static class Node 
	{
		int data;
		Node left, right;

		Node(int item) 
		{
			data = item;
			left = right = null;
		}
	}
	/* Compute the "maxDepth" of a tree -- the number of 
	nodes along the longest path from the root node 
	down to the farthest leaf node.*/
	int maxDepth(Node node) 
	{
		if (node == null){
			return 0;
		}
		else
		{
			System.out.println("inside else");
			/* compute the depth of each subtree */
			int lDepth = maxDepth(node.left);  //recursive call
			System.out.println("111111111 "+ lDepth);
			int rDepth = maxDepth(node.right);  //recursive call
			System.out.println("2222222 " + rDepth);

			/* use the larger one */
			if (lDepth > rDepth)
				return (lDepth + 1);
			else
				return (rDepth + 1);
		}
	}
	
	/* Driver program to test above functions */
	public static void main(String[] args) 
	{
		MaxDepthBinaryTree tree = new MaxDepthBinaryTree();

		tree.root = new Node(1);
		tree.root.left = new Node(2);
		tree.root.right = new Node(3);
		tree.root.left.left = new Node(4);
		tree.root.left.right = new Node(5);
		tree.root.left.right.left = new Node(6);

		System.out.println("Height of tree is : " + 
									tree.maxDepth(tree.root));
	}
}
