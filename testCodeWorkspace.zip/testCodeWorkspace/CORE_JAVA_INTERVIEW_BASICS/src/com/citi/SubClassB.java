package com.citi;

public class SubClassB implements MyInterfaceB{

	@Override
	public void add() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void multiplication() {
		// TODO Auto-generated method stub
		
	}
	

}
