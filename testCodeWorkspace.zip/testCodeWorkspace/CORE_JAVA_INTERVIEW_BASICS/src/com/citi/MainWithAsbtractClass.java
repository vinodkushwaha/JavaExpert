package com.citi;

//main method in abstract class -globant
//final main method -globant
public abstract class  MainWithAsbtractClass {

	public static final void main(String[] args) {
		System.out.println("test example");

	}

}
