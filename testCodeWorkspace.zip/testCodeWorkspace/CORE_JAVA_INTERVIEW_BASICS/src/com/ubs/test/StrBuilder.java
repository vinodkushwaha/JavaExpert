package com.ubs.test;

public class StrBuilder {

	public static void main(String[] args) {
		StringBuilder[] sb = { new StringBuilder("Layla"), new StringBuilder("Leila"), new StringBuilder("Sheila") };

		System.out.println("sbuilder is sb[2] " + sb[2]);
	}

}
