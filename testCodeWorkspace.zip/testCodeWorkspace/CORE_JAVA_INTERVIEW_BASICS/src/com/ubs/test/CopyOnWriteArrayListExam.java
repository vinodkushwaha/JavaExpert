package com.ubs.test;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class CopyOnWriteArrayListExam {

	public static void main(String[] args) {
		CopyOnWriteArrayList<String> lists = new CopyOnWriteArrayList<>();
		lists.add("London");
		lists.add("Paris");
		lists.add("Rome");
		Iterator<String> iterator = lists.iterator();
		lists.remove("Peris");
		while (iterator.hasNext()) {
			System.out.println(iterator.next() + " ");
		}
	}

}
/*London 
Paris 
Rome 
*/
