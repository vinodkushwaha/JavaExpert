package com.ubs.test;

public class MainAnimalReptile   {

	public static void main(String[] args) {
		/*
		 * public class MainAnimalReptile extends Reptile {
		 * 
		 * System.out.println("Before");
		new MainAnimalReptile();
		System.out.println("After");
		
		 Animal static block
		 Reptile static block
		 Before
		  Animal Intialize block
		  Animal constructor block
		 Reptile Initialize block
		 Reptile Constructor
		 After*/
		
		/////////////////2222222222222222///////////////
		System.out.println("Before");
		new Reptile();
		System.out.println("After");
		
/*		Before
		 Animal static block
		Reptile static block
		 Animal Intialize block
		 Animal constructor block
		Reptile Initialize block
		Reptile Constructor
		After
*/
	}

}
