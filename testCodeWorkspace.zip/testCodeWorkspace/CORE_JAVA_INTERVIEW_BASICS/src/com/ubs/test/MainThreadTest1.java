package com.ubs.test;

public class MainThreadTest1 {

	public static void main(String[] args) {
		ThreadTest1 pm1 = new ThreadTest1("1");
		pm1.run();
		ThreadTest1 pm2 = new ThreadTest1("1");
		pm2.run();
		
		ThreadTest1 pm3 = new ThreadTest1("break");
		pm3.run();
	}

}
