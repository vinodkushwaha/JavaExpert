package com.ubs.test;

public class Animal {
	{
		System.out.println(" Animal Intialize block");
	}
	
	public Animal() {
		System.out.println(" Animal constructor block");
	}
	static {
		System.out.println(" Animal static block");
	}

}

