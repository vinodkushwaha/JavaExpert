package com.ubs.test;

public enum Suit {
	DIMOND(Color.BLACK), HEART(Color.BLACK), SPADE(Color.BLACK), CLUB(Color.BLACK);
	
	private Color color;
	
	private Suit(Color colo) {
		this.color = colo;
	}

}
