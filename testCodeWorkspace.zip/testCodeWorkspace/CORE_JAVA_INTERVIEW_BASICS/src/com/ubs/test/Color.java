package com.ubs.test;

public interface Color {

	public static final String BLACK = "Black";


}
