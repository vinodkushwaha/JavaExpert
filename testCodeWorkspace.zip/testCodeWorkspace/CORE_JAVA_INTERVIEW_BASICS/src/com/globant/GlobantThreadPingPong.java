package com.globant;

//and 1 interview questions also include in that
class GlobantThreadPingPong implements Runnable
{
	String word;
	GlobantThreadPingPong(String s)
	{
		word = s;
	}
	public void run()
	{
		try
		{
			for (int i = 0; i < 30; i++)
			{
				System.out.println(word);
				Thread.sleep(100);
			}
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}
	}
	public static void main(String[] args)
    { 
		//Runnable is the parent class fo Thread
         Runnable p1 =  new GlobantThreadPingPong("ping");
        // Thread t3 = (Thread) p1; //asked in globant
        Thread    t1 = new Thread(p1);
     //   Runnable r1 =t1; //no casting required
         t1.start();
         //start another thread;
        Runnable p2 = new GlobantThreadPingPong("pong");
        Thread t2 = new Thread(p2);
        t2.start();
    }
}
