package com.globant;

public class MyThread extends Thread{  // implements Runnable{
	
	MyThread(){
		System.out.println(" Constructor");
	}

	@Override
	public void run() {
		System.out.println("MyThread run");		
	}

}
