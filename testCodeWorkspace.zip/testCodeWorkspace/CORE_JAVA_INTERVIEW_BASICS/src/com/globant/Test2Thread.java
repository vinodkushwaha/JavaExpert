package com.globant;

public class Test2Thread {
	public static void main(String[] args) {
		SampleThread A= new SampleThread("A");
		SampleThread B= new SampleThread("B");
		B.start();
		A.start();
	}
}
