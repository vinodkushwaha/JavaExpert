package com.globant;

public class MyException extends Throwable {

}
