package com.globant;

public class SampleThread extends Thread{
	
	private String threadName;
	
	private Thread t;
	SampleThread(String SampleThread ){
		this.threadName = SampleThread;
	}
	public void run(){
		while(true){
			System.out.println(threadName);
		}
	}
	public void start(){
		System.out.println("start");
		if(t==null){
			t = new Thread(this, threadName);
			t.start();
		}
	}

}
