package com.mindree.overriding.ConvarientreturnType;

class Child extends Parent{
    public Integer testMethod() 
    {
        System.out.println("Child");
        return 0;
    }
}

