package com.mindree.overriding.ConvarientreturnType;

public class DemoConvarient {

	public static void main(String[] args) {
		A1 a = new A1();
		a.method(new Integer(10));
		a.method(10);
		B1 b = new B1();
		b.method(new Integer(10));
		b.method(10);
	}

}
class A1{
	void  method(int i){
		System.out.println("int A1");
	}
	
}

class B1 extends A1 {
	void  method(Integer i){
		System.out.println("integer B1");
	}
}

/*int A1
int A1
integer B1
int A1*/