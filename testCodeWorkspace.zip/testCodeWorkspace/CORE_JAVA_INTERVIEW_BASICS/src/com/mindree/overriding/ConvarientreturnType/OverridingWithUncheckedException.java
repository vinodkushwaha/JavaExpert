package com.mindree.overriding.ConvarientreturnType;

public class OverridingWithUncheckedException {

	//Overriding method can throw Unchecked exception which is higher in hierarchy
    public static void main(String[] args){
        Shape5 s = new Circle5();
        s.draw();
    }
}
 
 class  Shape5{
    public void draw() throws ArithmeticException
    {
        System.out.println("Shape");
    }
}
 
class Circle5 extends Shape5{
    public void draw() throws RuntimeException 
    {
        System.out.println("Circle");
    }
}

