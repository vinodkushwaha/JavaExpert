package com.mindree.overriding.ConvarientreturnType;

public class CovariantReturnTypeIsOverriding {
//Its Overriding
	public static void main(String[] args) {
		   Parent2 p = new Child2();
	        p.testMethod();
	    }
	}
	 
	class Parent2{
	    public Number testMethod()
	    {
	        System.out.println("Parent");
	        return 0;
	    }
	}
	 class Child2 extends Parent2{
	    public Integer testMethod() 
	    {
	        System.out.println("Child");
	        return 0;
	    }
	}
