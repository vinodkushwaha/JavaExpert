package com.mindree.overriding.ConvarientreturnType;

import java.io.FileNotFoundException;
import java.io.IOException;

//Overriding method cannot throw checked exception which is higher in hierarchy
public class OverridingWithCheckedException {


    public static void main(String[] args){
        Shape6 s = new Circle6();
        try {
			s.draw();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
 
 class  Shape6{
    public void draw() throws IOException//IOException //FileNotFoundException 
    {
        System.out.println("Shape");
    }
}
 
class Circle6 extends Shape6{
    public void draw() throws FileNotFoundException//FileNotFoundException 
    {
        System.out.println("Circle");
    }
}

