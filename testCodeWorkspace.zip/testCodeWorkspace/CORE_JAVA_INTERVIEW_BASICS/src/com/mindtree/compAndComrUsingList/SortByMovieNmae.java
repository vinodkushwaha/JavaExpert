package com.mindtree.compAndComrUsingList;

import java.util.Comparator;

public class SortByMovieNmae implements Comparator<Movie> {

	@Override
	public int compare(Movie m1, Movie m2) {
		//ascending order
		//   return m1.getName().compareTo(m2.getName());
		   // //descending order
		   return m2.getName().compareTo(m1.getName());
	}

}
