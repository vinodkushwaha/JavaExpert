package com.mindtree.string;

public class Employee {
	private int id;
	private String name;
	
	@Override
	public int hashCode(){
		int hashcode;
		hashcode = id*20 + name.hashCode();
		return hashcode;
	}
	
	@Override
	public boolean equals(Object obj){
				
		if(obj != null && obj instanceof Employee){
			Employee emp = (Employee) obj;
			return (emp.id == this.id && emp.name.equals(this.name));
		}else{
			return false;
		}
		
	}
	Employee(int d, String n){
		this.id = d;
		this.name = n;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
