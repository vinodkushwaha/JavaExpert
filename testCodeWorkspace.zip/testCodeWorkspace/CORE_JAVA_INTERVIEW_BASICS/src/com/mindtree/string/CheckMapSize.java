package com.mindtree.string;

import java.util.HashMap;
import java.util.Map;

public class CheckMapSize {
	
	Map<String,Integer> maps = new HashMap<>();
		CheckMapSize(){
		maps.put("vinod", 100);
		maps.put("vinod2", 101);
	}

	public static void main(String[] args) {
		CheckMapSize c = new CheckMapSize();
		System.out.println(c.orgsize());
		// mapsize with employee obj with and without hashcode implementation and equal method
		Map<Employee,Integer> map = new HashMap<>();
		Employee e1 = new Employee(101, "vinod");
		Employee e2 = new Employee(101, "vinod");
		map.put(e1, 100);
		map.put(e2, 100);
		////MapSize::1 with Equal and HashCode impl in Employee Class
	    ////MapSize::2 without Equal and HashCode impl in Employee Class
		System.out.println("MapSize::" + map.size()); 
	}

	private int  orgsize() {
		return maps.size();
	}

}
