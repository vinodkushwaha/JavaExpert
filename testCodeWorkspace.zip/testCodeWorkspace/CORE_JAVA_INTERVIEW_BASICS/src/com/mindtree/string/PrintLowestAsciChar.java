package com.mindtree.string;

import java.util.Scanner;

public class PrintLowestAsciChar {
	
	public static void main(String[] arg){
		//String str = "zzbbaa";
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the input string ");
		String str = sc.nextLine();
		Character p = null;
		int min = (int) str.charAt(0);
		//System.out.println(st);
		for (int i = 1; i < str.length(); i++) {
			int c= (int)str.charAt(i);
			if(c < min){
				min = c;
				p = str.charAt(i);
			}
		}
		
		System.out.println(p);
	}

}
