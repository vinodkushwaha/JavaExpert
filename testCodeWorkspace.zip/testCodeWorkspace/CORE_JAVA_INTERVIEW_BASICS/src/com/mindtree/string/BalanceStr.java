package com.mindtree.string;

import java.util.HashSet;
import java.util.Set;

public class BalanceStr {

	public static void main(String[] args) {
		String str = "aabbd";
		Boolean b = checkStr(str);
		System.out.println("value ::" + b);
		String st = "abcdd";
		boolean s = CheckSingleOccurance(st);
		System.out.println("check single occurence :" + s);
	}

	private static boolean CheckSingleOccurance(String st) {
		Set<Character> c = new HashSet<>();
		boolean flag = true;
		for (int i = 0; i < st.length(); i++) {
			if (!c.add(st.charAt(i))) {
				flag = false;
				break;
			}
				
		}
		return flag;
	}

	private static Boolean checkStr(String str) {
		int n = str.length();
		boolean flag = true;
		int old_counter = 0;
		for (int i = 0; i < n; i++) {
			int cur_counter = 0;
			for (int j = 0; j < n; j++) {
				if (str.charAt(i) == str.charAt(j)) {
					++cur_counter;
				}
			}
			if (old_counter > 0 && old_counter != cur_counter) {
				flag = false;
				break;
			}
			old_counter = cur_counter;
		}
		return flag;
	}

}
