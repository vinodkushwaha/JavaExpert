package com.mindtree.string;


public class AnagramWithoutAnyCollection {  
   
    public static void main(String[] args) {  
    	//boolean b= checkAnagram("Keep", "Peek");  
    	
    	boolean b= checkAnagram("Mother In Law", "Hitler Woman");  
    	System.out.println("String is anagram : " + b);
    }  
    
    public static boolean checkAnagram(String first, String second){
        char[] characters = first.toLowerCase().toCharArray();
        //String Buffer is thread safe and slow use in multithreaded Env
        StringBuilder sbSecond = new StringBuilder(second.toLowerCase());
       // System.out.println(index1);
        if (first.length() != second.length()) {  
            return false; 
        }
        for(char ch : characters){
            int index = sbSecond.indexOf(Character.toString(ch));
            if(index != -1){
                sbSecond.deleteCharAt(index);
               System.out.println(sbSecond.length());
            }else{
                return false;
            }
        }
       
        return sbSecond.length()==0 ? true : false;
    }
}  
/*  static void isAnagram(String str1, String str2) {  
String s1 = str1.replaceAll("\\s", "");  
String s2 = str2.replaceAll("\\s", "");  
boolean status = true;  
if (s1.length() != s2.length()) {  
    status = false;  
} else {  
    char[] ArrayS1 = s1.toLowerCase().toCharArray();  
    char[] ArrayS2 = s2.toLowerCase().toCharArray();  
    Arrays.sort(ArrayS1);  
    Arrays.sort(ArrayS2);  
    status = Arrays.equals(ArrayS1, ArrayS2);  
}  
if (status) {  
    System.out.println(s1 + " and " + s2 + " are anagrams");  
} else {  
    System.out.println(s1 + " and " + s2 + " are not anagrams");  
}  
} */ 