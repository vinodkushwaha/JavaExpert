package com.mindtree.string;
import java.util.Scanner;
public class BalanceStringPgm {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		String str = sc.nextLine();
		char[] c = str.toCharArray();
		int res = (int) c[0];
		for (char d : c) {
			res = res^(int)d;
		}
		System.out.println(res);
	}
}