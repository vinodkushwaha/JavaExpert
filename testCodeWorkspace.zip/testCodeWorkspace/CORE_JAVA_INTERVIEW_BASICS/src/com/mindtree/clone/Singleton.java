package com.mindtree.clone;

//Singleton class
class Singleton extends SuperClass {
	// public instance initialized when loading the class
	private static final Singleton instance = new Singleton();

	private Singleton() {
		// private constructor
	}
	
	
	//Solution 1
	/*  @Override
	  protected Object clone() throws CloneNotSupportedException 
	  {
	    throw new CloneNotSupportedException();
	  }*/
	
	//Solution 2
	/*  @Override
	  protected Object clone() throws CloneNotSupportedException 
	  {
	    return instance;
	  }*/
	  
	  public static Singleton getInstance(){
		  return instance;
	  }

}
