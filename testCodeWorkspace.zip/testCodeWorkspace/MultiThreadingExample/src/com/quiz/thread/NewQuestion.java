package com.quiz.thread;

//What will be the output of the following program?

public class NewQuestion {
	public static void main(String[] args) {
		new VolatileTest("Merit").run();
		new VolatileTest("Campus").run();
	}
}

class VolatileTest extends Thread {
	private volatile int testValue;
	private volatile boolean ready; //value can not by thread locally default is false

	public VolatileTest(String str) {
		super(str);
	}

	public void run() {
		for (int i = 0; i < 2; i++) {
			try {
				if (getName().equals("Merit")) {
					ready = true; //changing value at thread level
					testValue = i;
					System.out.println(getName() + ", " + ready + ", "
							+ testValue);
				}
				if (getName().equals("Campus")) {
					System.out.println(getName() + ", " + ready + ", "
							+ testValue);
				}
				Thread.sleep(1000);
			} catch (InterruptedException exception) {
				exception.printStackTrace();
			}
		}
	}
}
