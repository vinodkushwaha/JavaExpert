package com.quiz.thread;

//What will be the output of the following program?

public class HowMayTimes implements Runnable {
	int k = 0;

	public HowMayTimes(int i) {
		k = i;
	}

	public static void main(String[] args) {
		new HowMayTimes(2).run();
		new HowMayTimes(1).run();
	}

	public void run() {
		for (int i = 0; i < k; i++)
			System.out.println("Simple Question");
	}
}

/*Simple Question
Simple Question
Simple Question*/