package com.mindtree.soting.algo;

/*Description:
 Bubble sort is a simple sorting algorithm that works by repeatedly 
 stepping through the list to be sorted, comparing each pair of adjacent items
 and swapping them if they are in the wrong order. The pass through the list is 
 repeated until no swaps are needed, which indicates that the list is sorted. 
 The algorithm gets its name from the way smaller elements bubble to the top
 of the list. Because it only uses comparisons to operate on elements,
 it is a comparison sort. You can see the code implementation below:*/
public class MyBubbleSort {
	// logic to sort the elements
	public static void bubble_srt(int array[]) {
		int count =1;
		for (int i = 0; i < array.length; i++) {
			//main logic
			// 2 element used so   (array.length -1)
			for (int current = 0; current < array.length - 1; current++) {
				//swap if next element smaller than current element
				int next = current +1;
				if ( array[current] > array[next] ) {
					// swapNumbers(i+1 , i, array);
					int smallest = array[next];
					array[next] = array[current];
					array[current] = smallest;
				}
			}
			// { 4, 2, 9, 6, 23, 12, 34, 0, 1 };
			System.out.println("loop count " + count++);
			printNumbers(array);
		}
	}

	private static void swapNumbers(int i, int j, int[] array) {
		int temp;
		temp = array[i];
		array[i] = array[j];
		array[j] = temp;
	}

	private static void printNumbers(int[] input) {
		for (int i = 0; i < input.length; i++) {
			System.out.print(input[i] + ", ");
		}
		System.out.println("\n");
	}

	public static void main(String[] args) {
		int[] input = { 4, 2, 9, 6, 23, 12, 34, 0, 1 };
		bubble_srt(input);
	}
}