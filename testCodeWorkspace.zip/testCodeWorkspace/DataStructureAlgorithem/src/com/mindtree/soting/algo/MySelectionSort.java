package com.mindtree.soting.algo;

public class MySelectionSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array1 = { 10, 34, 2, 56, 7, 67, 88, 42 };
		int[] array2 = selectionsort(array1);
		for (int i : array2) {
			System.out.println(i + ",");
		}
	}

	private static int[] selectionsort(int[] array1) {
		// loop to move value at proper position in asscending order
		for (int i = 0; i < array1.length; i++) {
			int index = i;
			// loop to find next smallest element in whole array
			for (int j = i + 1; j < array1.length ; j++) {
				if (array1[j] < array1[index]) {
					index = j; // keep udating index for smallest element of array
				}
			}
			int smallestNumber = array1[index];
			array1[index] = array1[i];
			array1[i] = smallestNumber;

		}
		return array1;

	}

}
