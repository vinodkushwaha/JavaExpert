package com.mindtree.program.interview.BoxingAndUnBoxing;

class VarargsDemo
{
  public static void main (String[] args)
  {
    byte b = 5;
    aMethod(b, b);
  }
 
  static void aMethod (byte... b)
  {
    System.out.println("byte, byte");
  }
 
  static void aMethod (int b, int c)
  {
    System.out.println("int, int");
  }
}
 
/*OUTPUT
======
int, int
*/