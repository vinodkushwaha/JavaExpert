package com.mindtree.twoD;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SynchronizedList {

	public static void main(String[] args) {
   List<Integer> l = new ArrayList<Integer>();
   l.add(5);
   l.add(9);
   Collections.synchronizedList(l);
   l.add(10);
  
   System.out.println(l);
	}

}
