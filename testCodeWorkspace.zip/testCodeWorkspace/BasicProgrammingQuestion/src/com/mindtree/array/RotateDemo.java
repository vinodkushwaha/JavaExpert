package com.mindtree.array;

//Java program to demonstrate rotation of array
//with Collections.rotate()
import java.util.*;

public class RotateDemo {
	public static void main(String[] args) {
		// Let us create an array of integers
		Integer arr[] = { 10, 20, 30, 40, 50 };

		Integer tmp[] = new Integer[5];
		int rf = 3;
		rotate(arr, tmp, rf);

		// System.out.println("Original Array : " + Arrays.toString(arr));

		// Please refer below post for details of asList()
		// https://www.geeksforgeeks.org/array-class-in-java/
		// rotating an array by distance 2
		// Collections.rotate(Arrays.asList(arr), 2);

		// System.out.println("Modified Array : " + Arrays.toString(arr));
	}

	// [40, 50, 10, 20, 30] rf=2
	// [30, 40, 50, 10, 20] rf=3
	private static void rotate(Integer[] arr, Integer[] tmp, int rf) {
		int k = 0;
		int n = arr.length - 1;
		if (rf != 0) {
			for (int i = rf; i <=n; i++) {
				tmp[i] = arr[k++];
			}
			while (rf - 1 >= 0) {
				tmp[--rf] = arr[n--];
			}
			List<Integer> lis = Arrays.asList(tmp);
			System.out.println(lis);
		}

	}

}