package com.mindtree.array;

public class ArrayPgmBarclays {

	public static void main(String[] args) {
		int[] a= {1,2,3,4,5};
		int[] b = new int[2];
		System.out.println(b.length); //2
		 b= a; //b has a reference of a
		 System.out.println(b.length); //5
		 for (int i = 0; i < b.length; i++) {
			 System.out.println(b[i] + " ");
		}

	}

}
