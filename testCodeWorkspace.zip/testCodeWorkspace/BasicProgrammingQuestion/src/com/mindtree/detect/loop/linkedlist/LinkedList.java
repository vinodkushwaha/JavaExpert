package com.mindtree.detect.loop.linkedlist;

//Java program to detect and remove loop in linked list

public class LinkedList {

	private static Node head;

	private static class Node {

		int data;
		Node next;

		Node(int d) {
			data = d;
			next = null;
		}
	}

	// Function that detects loop in the list
	void detectAndRemoveLoop(Node head) {

		// If list is empty or has only one node
		// without loop
		if (head == null || head.next == null)
			return;

		Node slow = head, fast = head;

		// Move slow and fast 1 and 2 steps
		// ahead respectively.
		slow = slow.next;
		fast = fast.next.next;

		// Search for loop using slow and fast pointers
		while (fast != null && fast.next != null) {
			if (slow == fast) {
				System.out.println("loop exist");
				while (head.next != fast.next) {
					head = head.next;
					fast = fast.next;
				}
				System.out.println("loop start Node " + head.next.data);
				fast.next = null; /* remove loop */
			} else {
				slow = slow.next;
				fast = fast.next.next;
			}

		}

	}

	// Function to print the linked list
	void printList(Node node) {
		while (node != null) {
			System.out.print(node.data + " ");
			node = node.next;
		}
	}

	// Driver program to test above functions
	public static void main(String[] args) {
		LinkedList list = new LinkedList();
		list.head = new Node(50);
		list.head.next = new Node(20);
		list.head.next.next = new Node(15);
		list.head.next.next.next = new Node(4);
		list.head.next.next.next.next = new Node(100);
		// System.out.println(head.next.data);
		// System.out.println("\n" + head.next.next.next.next.next);
		// Creating a loop for testing
		     head.next.next.next.next.next = head.next.next.next;
		list.detectAndRemoveLoop(head);
		System.out.println("Linked List after removing loop : ");
		list.printList(head);
	}
}

// This code has been contributed by Mayank Jaiswal