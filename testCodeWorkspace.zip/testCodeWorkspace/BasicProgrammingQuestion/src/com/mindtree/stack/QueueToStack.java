package com.mindtree.stack;

import java.util.LinkedList;
import java.util.Queue;

public class QueueToStack {
	Queue<Integer> q = new LinkedList<>();

	public void push(int data) {
		int s = q.size();
		q.add(data);
		for (int i = 0; i < s; i++) {
			int dequeue = q.remove();
			q.add(dequeue);
		}

	}

	private int pop() {
		if (q.size() == 0) {
			return -1;
		}

		return q.remove();
	}

	public static void main(String[] args) {

		QueueToStack stack = new QueueToStack();
		stack.push(10);
		stack.push(50);
		System.out.println(stack.pop());
		stack.push(70);
		stack.push(30);
	//	System.out.println(stack.pop());
		System.out.println(stack.getTop());

	}

	private int getTop() {
		if (q.size() == 0) {
			return -1;
		}
		
		return q.peek();
	}

}
