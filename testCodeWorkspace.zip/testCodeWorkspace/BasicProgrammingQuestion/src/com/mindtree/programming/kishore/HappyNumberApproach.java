package com.mindtree.programming.kishore;

import java.util.HashSet;
import java.util.Set;
/*
 /*	
 Input: n = 19
Output: True
19 is Happy Number,
1^2 + 9^2 = 82
8^2 + 2^2 = 68
6^2 + 8^2 = 100
1^2 + 0^2 + 0^2 = 1
As we reached to 1, 19 is a Happy Number.

Input: n = 20
Output: False
 * Happy number: Starting with any positive integer, replace the number by the sum 
of the squares of its digits, and repeat the process until 
the number equals 1, or it loops endlessly in a cycle which does not include 1.*/
public class HappyNumberApproach {
	
public static void main(String[] args){
	int num=13;
	if(happy_num(num)){
        System.out.println(num + " Is a Happy Number");
        
    }else {
    	System.out.println(num + " Not a Happy number");
    }

}
	/*int num=7;
	System.out.println(num/10); // output 0
*/   public static boolean happy_num(int num){
	   int  sum = 0;
       int digit = 0;
       Set<Integer> cycle = new HashSet<>();
       //cycle.add(num)  if its returning same number after squaring
	   while(num != 1 && cycle.add(num)){
		   sum =0;
           while(num > 0){
        	   digit = (num % 10);
        	   System.out.println("digit ::"+ 19%10+ ":::" + digit);
        	   sum= sum + digit*digit;
               num = num/10;
           }
           num = sum;
       }
       return num == 1;
   }   
 }