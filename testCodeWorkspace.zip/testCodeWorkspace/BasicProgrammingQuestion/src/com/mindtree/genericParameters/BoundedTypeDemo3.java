package com.mindtree.genericParameters;

//What will be the output of the following program?

public class BoundedTypeDemo3 {
	public static void main(String args[]) {
		BoundedType3<First> obj1 = new BoundedType3<First>(new First());
		obj1.print();
		BoundedType3<Second> obj2 = new BoundedType3<Second>(new Second());
		obj2.print();
	}
}

class BoundedType3<T extends MyName> {
	T obj;

	BoundedType3(T obj) {
		this.obj = obj;
	}

	void print() {
		obj.printName();
	}
}

interface MyName {
	void printName();
}

class First implements MyName {

	public void printName() {
		System.out.println("Hi... This is First class");
	}

}

class Second implements MyName {
	public void printName() {
		System.out.println("Hi... This is Second class");
	}
}
/*
Hi... This is First class
Hi... This is Second class*/