package com.mindtree.genericParameters;

public class BoundedTypeDemo1 {
	public static void main(String args[]) {
		BoundedType1<Integer> obj1 = new BoundedType1<Integer>();
		obj1.addSum(5);
		obj1.addSum(11);
		System.out.println("Value 2 :" + obj1.getSum());
		BoundedType1<Float> obj2 = new BoundedType1<Float>();
		obj2.addSum(new Float(11.5));
		obj2.addSum(new Float(18.5));
		
		System.out.println("Value 1 :" + obj2.getSum());
	}
}

class BoundedType1<T extends Number> {
	double sum = 0.0;

	void addSum(T item) {
		sum += item.doubleValue();
	}

	double getSum() {
		return sum;
	}
}
/*
 * Value 2 :16.0
*  Value 1 :30.0
*/
// BASIL extends Number Class