package com.mindtree.genericParameters;


//What will be the output of the following program?
//default sort by ket
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
public class Test {
    public static void main(String args[]){  
        Map<Integer,String> map = new HashMap<Integer,String>();  
        map.put(1,"Merit");  
        map.put(6,"Mulesoft"); 
        map.put(5,"Angular"); 
        map.put(3,"Java");  
        map.put(2,"Campus");
        map.put(4,"School");
            
        Set<Entry<Integer,String>> set = map.entrySet();  
        Iterator<Entry<Integer,String>> itr = set.iterator();
        while(itr.hasNext()){  
            Entry e = itr.next();
            System.out.println(e.getKey()+" "+e.getValue());  
        }  
    }
}