package com.mindtree.genericParameters;

public class BoundedTypeDemo5 {
	public static void main(String args[]) {
		BoundedType5<Firsts> obj1 = new BoundedType5<Firsts>(new Seconds());
		obj1.print();
	}
}

class BoundedType5<T extends MyNames> {
	T obj;

	BoundedType5(T obj) {
		this.obj = obj;
	}


	void print() {
		obj.printName();
	}
}

interface MyNames {
	void printName();
}

class Firsts implements MyNames {

	public void printName() {
		System.out.println("Hi... This is First class");
	}

}

class Seconds implements MyNames {
	public void printName() {
		System.out.println("Hi... This is Second class");
	}
}
