package com.mindtree.lamdaExpression;

public  class StateOwner {

    public void addStateListener(StateChangeListener listener) {
    	System.out.println("inside stateOwner class");
	}
    
    public void display(){
    	System.out.println("hellow");
    }

}

