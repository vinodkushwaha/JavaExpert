package com.mindtree.singleton.pattern;

public class EagerInitializedSingleton {

	private EagerInitializedSingleton(){}
	
	private static final EagerInitializedSingleton instance = new EagerInitializedSingleton();
	
	public static EagerInitializedSingleton getInstance(){
		return instance;
		
	}
	public static void main(String[] args){
		EagerInitializedSingleton obj = EagerInitializedSingleton.getInstance();
		System.out.println("EagerInitializedSingleton :" + obj);
	}
}
