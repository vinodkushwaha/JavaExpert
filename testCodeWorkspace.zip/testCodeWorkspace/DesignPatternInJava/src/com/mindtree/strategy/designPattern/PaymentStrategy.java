package com.mindtree.strategy.designPattern;

public interface PaymentStrategy {
	public void pay(int amount);
}
