package com.mindtree.lamdaExpression;

public class State {

}
