package com.mindtree.MultipleInheritance;

public interface B extends A {
	 }

