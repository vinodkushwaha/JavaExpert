package com.mindree.overriding.ConvarientreturnType;

public class Circle extends Shape{
    public void draw() throws RuntimeException 
    {
        System.out.println("Circle");
    }

}
