package com.mindree.overriding.ConvarientreturnType;

public class Circle1 extends Shape1 {
    public void draw() throws RuntimeException 
    {
        System.out.println("Circle 1 Checked Exception Demo");
    }

}
