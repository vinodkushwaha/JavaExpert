package com.mindtree.string;

public class Test {

	// Scenario1 +  Scenario3  op://String
/*	public void foo(String s) {
		System.out.println("String");
	}*/
	

	// Scenario2 + Scenario3    op:array of String
	public void foo(String[] s) {
		System.out.println("array of String");
	}
	// Scenario3
	public void foo(Object o) {
		System.out.println("Object");
	}
	
	// Scenario 2
/*	Above program compiles perfectly and when we run it, it prints �String�.

	So the method foo(String s) was called by the program. The reason behind 
	this is java compiler tries to find out the method with most specific input 
	parameters to invoke a method. We know that Object is the parent class of String, 
	so the choice was easy. Here is the excerpt from Java Language Specification.*/


	// common
	/*public void foo(StringBuffer sb) {
		System.out.println("StringBuffer");
	}*/

	public static void main(String[] args) {
		// The above program will not compile with error
		// as "The method foo(String) is ambiguous for the type Test".
		 new Test().foo(null);
	}

}
