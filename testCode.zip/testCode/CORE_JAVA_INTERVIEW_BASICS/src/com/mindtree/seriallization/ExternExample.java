package com.mindtree.seriallization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ExternExample {
	 public static void main(String[] args)
	 {
	     Car car = new Car("Shubham", 1995);
	     Car newcar = null;

	     // Serialize the car Object to Stream
	     try {
	         FileOutputStream fo = new FileOutputStream("d://gfg.txt");
	         ObjectOutputStream so = new ObjectOutputStream(fo);
	         so.writeObject(car);
	         so.flush();
	     }
	     catch (Exception e) {
	         System.out.println(e);
	     }

	     // Deserializa the car Stream to Car Object
	     try {
	         FileInputStream fi = new FileInputStream("d://gfg.txt");
	         ObjectInputStream si = new ObjectInputStream(fi);
	         newcar = (Car)si.readObject();
	     }
	     catch (Exception e) {
	         System.out.println(e);
	     }

	     System.out.println("The original car is:\n" + car);
	     System.out.println("The new car is:\n" + newcar);
	 }
	}
