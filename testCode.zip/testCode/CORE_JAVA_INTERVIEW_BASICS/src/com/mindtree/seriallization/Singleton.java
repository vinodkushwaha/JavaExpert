package com.mindtree.seriallization;

import java.io.Serializable;

public class Singleton implements Serializable 
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// public instance initialized when loading the class
    public static Singleton instance = new Singleton();
     
    private Singleton() 
    {
        // private constructor
    }
    
    // implement readResolve method to get same instance and issue resolved
    protected Object readResolve()
    {
        return instance;
    }

}
