package com.mindtree.hashmap.interview;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class HashMapSorting{ 
	// static public   void   main(String args[])  {
	
	    //or
	 public static  void   main(String args[])  {
		
		// let's create a map with Java releases and their code names 
		HashMap<String, String> mapobj = new HashMap<String, String>(); 
		mapobj.put("JDK 1.1.4", "Sparkler");
		mapobj.put("J2SE 1.2", "Playground");
		mapobj.put("J2SE 1.3", "Kestrel");
		mapobj.put("J2SE 1.4", "Merlin");
		mapobj.put("J2SE 5.0", "Tiger"); 
		mapobj.put("Java SE 6", "Mustang"); 
		mapobj.put("Java SE 7", "Dolphin");
		System.out.println("HashMap before sorting, random order "); 
		Set<Entry<String, String>> setOfentries = mapobj.entrySet();
		
		
		for(Entry<String, String> entry : setOfentries){
			System.out.println(entry.getKey() + " ==> " + entry.getValue()); 
			}

		// Now let's sort HashMap by keys first 
		// allyouneed to do is create a TreeMap with mappings of HashMap 
		// TreeMap keeps all entries in sorted order 
		TreeMap<String, String> sorted = new TreeMap<String, String>(mapobj);
		Set<Entry<String, String>> mappings = sorted.entrySet(); 
		System.out.println("HashMap after sorting by Keys in ascending order"); 
		for(Entry<String, String> mapping : mappings){ 
			System.out.println(mapping.getKey() + " ==> " + mapping.getValue()); 
			}

	/*	Iterator<Entry<String, String>> itermappings = mappings.iterator();
		while(itermappings.hasNext()){
			Entry<String, String> ent = itermappings.next();
			ent.getKey();
			ent.getValue();
		}*/
		
		// Now let's sort the HashMap by values
		// there is no direct way to sort HashMap by values but you
		// can do this by writing your own comparator, which takes 
		// Map.Entry object and arrange them in order increasing 
		// or decreasing by values. 
		Comparator<Entry<String, String>> valueComparator = new Comparator<Entry<String, String>>() {
			@Override
			public int compare(Entry<String, String> e1,
					Entry<String, String> e2) {
				String v1 = e1.getValue();
				String v2 = e2.getValue();
				return v1.compareTo(v2);
			}
		};
			// Sort method needs a List, so let's first convert Set to List in Java
			//Set<Entry<String, String>> entries = codenames.entrySet();
			List<Entry<String, String>> listOfEntries = new ArrayList<Entry<String, String>>(setOfentries);
			// sorting HashMap by values using comparator
			Collections.sort(listOfEntries, valueComparator);
			
			
			//************** LinkedHashMap preserves the insertion order***********************
			
			LinkedHashMap<String, String> sortedByValue = new LinkedHashMap<String, String>(listOfEntries.size());
			// copying entries from List to Map
			for(Entry<String, String> entry : listOfEntries)
			{
				sortedByValue.put(entry.getKey(), entry.getValue());
			} 
			System.out.println("HashMap after sorting entries by values ");
			Set<Entry<String, String>> entrySetSortedByValue = sortedByValue.entrySet();
			for(Entry<String, String> mapping : entrySetSortedByValue)
			{ 
				System.out.println(mapping.getKey() + " ==> " + mapping.getValue());
				}
			}
	}



