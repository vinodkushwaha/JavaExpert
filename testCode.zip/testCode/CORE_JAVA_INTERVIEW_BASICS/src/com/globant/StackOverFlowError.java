package com.globant;

public class StackOverFlowError {

	/**
	 * at com.glob.StackOverFlowError.print(StackOverFlowError.java:14) at
	 * com.glob.StackOverFlowError.print(StackOverFlowError.java:14)
	 */
	public static void main(String[] args) {
		print(10);

	}

	private static void print(int i) {
		print(10);

	}

}
