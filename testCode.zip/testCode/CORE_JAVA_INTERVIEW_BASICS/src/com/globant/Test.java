package com.globant;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Thread t = new MyThread() {
			public void run(){
				System.out.println("in main class  ");
			}
		};
	
	     t.start();
	}
	
}
