package com.globant;

public class TestMyThread {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Thread t = new MyThread() {
			public void run(){
				System.out.println("in main class  ");
			}
		};
	
	     t.start();
	}
	
}
