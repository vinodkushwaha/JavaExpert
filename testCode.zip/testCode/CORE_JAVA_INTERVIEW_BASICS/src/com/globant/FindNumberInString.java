package com.globant;

public class FindNumberInString {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String s = "vinod2kush";
		int n = s.length();

		for (int i = 0; i < n - 1; i++) {
			if (Character.isDigit(s.charAt(i))) {
				System.out.println(s.charAt(i));
			}
		}
	}

}
