package com.globant;

import java.util.StringTokenizer;

public class StringTokenizerExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String s = "My Name is Vinod";
		StringTokenizer st = new StringTokenizer(s, " ");
		String sl = "";
		while (st.hasMoreTokens()) {
			sl = st.nextToken() + sl;

			System.out.println(sl);
		}

	}

}
