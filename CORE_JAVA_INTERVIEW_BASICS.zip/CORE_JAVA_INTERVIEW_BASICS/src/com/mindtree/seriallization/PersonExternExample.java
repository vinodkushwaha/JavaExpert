package com.mindtree.seriallization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class PersonExternExample {
	 public static void main(String[] args)
	 {
		 Person person = new Person("Shubham", 100,"LIC OFFICE");
	     Person newper = null;

	     // Serialize the car Object to Stream
	     try {
	         FileOutputStream fo = new FileOutputStream("d://person.txt");
	         ObjectOutputStream so = new ObjectOutputStream(fo);
	         so.writeObject(person);
	         so.flush();
	     }
	     catch (Exception e) {
	         System.out.println(e);
	     }

	     // Deserializa the car Stream to Car Object
	     try {
	         FileInputStream fi = new FileInputStream("d://person.txt");
	         ObjectInputStream si = new ObjectInputStream(fi);
	         newper = (Person)si.readObject();
	     }
	     catch (Exception e) {
	         System.out.println(e);
	     }

	     System.out.println("The original Person is:\n" + person);
	     System.out.println("The new Person is:\n" + newper);
	 }
	}
