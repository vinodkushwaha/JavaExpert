package com.mindtree.enumEx;

public class EnumDemo {
    public static void main(String[] args) {
        SingletonEnum singleton = SingletonEnum.INSTANCE;
        System.out.println(singleton.getValue());
        singleton.setValue(2);
        System.out.println(singleton.getValue());
        singleton.setValue(3);
        System.out.println(singleton.getValue());
        SingletonEnum singleton1 = SingletonEnum.INSTANCE;
        
        if(singleton == singleton1){
        	System.out.println("same instance");
        }
        else{
        	System.out.println("false");
        }
     
    }
}

