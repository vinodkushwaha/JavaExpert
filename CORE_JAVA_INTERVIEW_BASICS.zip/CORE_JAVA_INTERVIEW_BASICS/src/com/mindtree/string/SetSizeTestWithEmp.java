package com.mindtree.string;

import java.util.HashSet;
import java.util.Set;

public class SetSizeTestWithEmp {
	public static void main(String[] args) {
		Set<Employee> sets = new HashSet<>();
		
		// mapsize with employee obj with and without hashcode implementation and equal method
		Employee e1 = new Employee(101, "vinod");
		Employee e2 = new Employee(101, "vinod");
		sets.add(e1);
		sets.add(e2);
		////SetSize::1 with Equal and HashCode impl in Employee Class
	    ////SetSize::2 without Equal and HashCode impl in Employee Class
		System.out.println("SetSize::" + sets.size()); 
	}

}
