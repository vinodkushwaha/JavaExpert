package com.globant;

public class TestTRyCatch {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		try {
			throw new MyException();
		} catch (Throwable e) {
			e.printStackTrace();
		}

		finally {

		}
	}

}
