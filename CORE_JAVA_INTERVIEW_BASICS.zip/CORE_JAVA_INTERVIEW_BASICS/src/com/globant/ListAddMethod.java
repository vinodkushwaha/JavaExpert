package com.globant;

import java.util.ArrayList;

public class ListAddMethod {

	/**
	 * Exception in thread "main" java.lang.IndexOutOfBoundsException: Index: 1, Size: 0
	at java.util.ArrayList.add(Unknown Source)
	at com.glob.ListAddMethod.main(ListAddMethod.java:15)
	 */
	public static void main(String[] args) {
		ArrayList<Object> list = new ArrayList<Object>();
		Object object1 = new Object();
		Object object2 = new Object();
		Object object3 = new Object();
		list.add(1, object1);
		list.add(3, object3);
		list.add(2, object2);
		System.out.println(list);

	}

}
