package com.deoutchBank;

public class CanWeOverrideStaticMethod {
	public static void main(String[] str){
		
		SubClass s = new SubClass(); //op: inside subclass class
		SuperClass d = new SubClass(); //op: inside super class             // which means its method hiding
		SuperClass a = new SuperClass();//op::inside super class
		/*SubClass.display();
		SuperClass.display();*/
		d.display();
	}
}
