package com.mindree.overriding.ConvarientreturnType;

import java.io.IOException;

public class Linux extends Unix {

	@Override
	public void whoAmI() throws IOException{
		System.out.println("I am UNIX");
	}
}
