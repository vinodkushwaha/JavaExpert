package com.mindree.overriding.ConvarientreturnType;

public class  Shape{
    public void draw() throws ArithmeticException
    {
        System.out.println("Shape");
    }
}
