package com.mindree.overriding.ConvarientreturnType;

public class CovariantArguIsNotOverriding {
//================================Its Not Overriding========================================
	public static void main(String[] args) {
		   Parent4 p = new Child4();
	        p.testMethod(4);
	    }
	}
	 
	class Parent4{
		//================================Its Not Overriding========================================
		public void testMethod(Number n)
	    {
	        System.out.println("Parent");
	    }

	}
	 class Child4 extends Parent4{
		//================================Its Not Overriding========================================
		    public void testMethod(Integer n) 
		    {
		        System.out.println("Child");
		    }

	}
