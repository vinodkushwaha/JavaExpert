package com.barclays;

public class Test {

	public static void main(String[] args) {
		MethodOverLoad m = new MethodOverLoad();
		m.run();
      System.out.println("hiiiiiii");
	}

}
