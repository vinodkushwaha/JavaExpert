package com.mindtree.strategy.designPattern;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {

	//List of items
	List<Item> listOfItems;
	
	public ShoppingCart(){
		this.listOfItems=new ArrayList<Item>();
	}
	
	public void makePayment(PaymentStrategy paymentMethod){
		int amount = calculateTotal();
		paymentMethod.pay(amount);
	}
	
	public void addItem(Item item){
		this.listOfItems.add(item);
	}
	
	public void removeItem(Item item){
		this.listOfItems.remove(item);
	}
	
	public int calculateTotal(){
		int sum = 0;
		for(Item item : listOfItems){
			sum += item.getPrice();
		}
		return sum;
	}
	
	
}