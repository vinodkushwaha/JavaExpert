package com.mindtree.builder.proxyDesignPattern;

public interface Internet
{
    public void connectTo(String serverhost) throws Exception;
}
