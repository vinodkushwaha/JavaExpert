package str;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class MainForInsertRecords {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SessionFactory factory = 
				new Configuration().configure().buildSessionFactory();
/*		
		Product product = new Product();
		product.setProductId(100);
		product.setProName("Powder");
		product.setPrice(100);*/
		
		Product product1 = new Product();
		product1.setProductId(102);
		product1.setProName("Oil");
		product1.setPrice(200);
		
		Product product2 = new Product();
		product2.setProductId(101);
		product2.setProName("Cream");
		product2.setPrice(500);
		
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		//interview question
			Integer id = (Integer)session.save(product2);
			/*Integer id1 = (Integer)session.save(vehicle);
			System.out.println("id :" + id +":::id1 "+id1);*/
		tx.commit();
		session.close();
		System.out.println("product with " + id + " saved success");
		
	}

}
