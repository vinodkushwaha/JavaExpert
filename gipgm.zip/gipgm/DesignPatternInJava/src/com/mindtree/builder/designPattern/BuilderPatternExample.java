package com.mindtree.builder.designPattern;


public class BuilderPatternExample {
	  
	public static void main(String args[]) {
		
		Cake whiteCake1 = new Cake.Builder().build();
		
		//Cake n = new Cake(new Builder()); error

		// Creating object using Builder pattern in java
		Cake whiteCake = new Cake.Builder().sugar(1).butter(0.5).eggs(2)
				.vanila(2).flour(1.5).bakingpowder(0.75).milk(0.5).build();

		// Cake is ready to eat :)
		System.out.println(whiteCake);
	}
}


