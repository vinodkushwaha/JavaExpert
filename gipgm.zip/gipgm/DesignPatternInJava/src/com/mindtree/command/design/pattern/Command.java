package com.mindtree.command.design.pattern;

public interface Command {
    public abstract void execute ( );
}
