package com.mindtree.strategy.designPattern;

public class PaypalStrategy implements PaymentStrategy {
	private String emailId;
	private String password;
	@Override
	public void pay(int amount) {
		System.out.println(amount + " paid using Paypal.");
	}
		
		
		public PaypalStrategy(String email, String pwd){
			this.emailId=email;
			this.password=pwd;
		}
		
	}
