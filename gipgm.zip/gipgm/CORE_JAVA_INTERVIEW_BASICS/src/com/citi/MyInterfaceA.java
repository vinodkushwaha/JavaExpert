package com.citi;

public interface MyInterfaceA {

	void add();
	void delete();
	void multiplication();
}
