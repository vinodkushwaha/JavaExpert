package com.citi;

//asked in citi
public class SubClassA extends SuperClassA {
	
	public static void main(String [] arg){
		SuperClassA supObjRef = new SubClassA();
		SubClassA childObjRef = new SubClassA();
		supObjRef.rectrangle(); //Methods of child class not be accessible
		
		//sub class type reference
		childObjRef.circle();   //all methods will be accessible
		childObjRef.doSomthing();   //all methods will be accessible
	}
	@Override
	public void circle(){
		System.out.println("Circle Subclass");
	}
public void doSomthing(){
		System.out.println("do something");
	}
}
