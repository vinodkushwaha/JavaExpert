package com.citi;

public interface MyInterfaceB {

	void add();
	void delete();
	void multiplication();
}
