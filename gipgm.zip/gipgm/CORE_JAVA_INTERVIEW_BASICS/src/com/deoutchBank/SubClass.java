package com.deoutchBank;

public class SubClass extends SuperClass {

	public static void display(){
		System.out.println("inside subclass class");
	}
	//or
	/*public static void display(){
	System.out.println("inside subclass class");
}*/
	

}
