package com.mindree.overriding.ConvarientreturnType;
//Does java allows covariant method parameters? ======Nooooooooooooooooo
//only covariant return type allowed in java for overriding
public class PumpkinDemo {
    public static void main(String[] args){
       Parent p = new Child();
       p.testMethod();
       
       
       Shape s = new Circle();
       s.draw();
       
       Shape1 s1 = new Circle1();
       s1.draw();

   }
}

