package com.mindree.overriding.ConvarientreturnType;

class Parent{
    public Number testMethod()
    {
        System.out.println("Parent");
        return 0;
    }
}
