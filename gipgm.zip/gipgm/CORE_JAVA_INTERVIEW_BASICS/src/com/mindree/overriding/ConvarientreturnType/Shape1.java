package com.mindree.overriding.ConvarientreturnType;

public class  Shape1{
    public void draw() throws ArithmeticException
    {
        System.out.println("Shape Checked Exception Demo");
    }
}
