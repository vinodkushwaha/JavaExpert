
package com.mindree.overriding.ConvarientreturnType;


public class Unix {

	public void whoAmI() throws Exception {
		System.out.println("I am UNIX");
	}
}
