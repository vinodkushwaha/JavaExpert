package com.mindtree.string;

public class StringTest {

	public static void main(String[] args) {
		// scenario 1
		String s1 = new String("pankaj");
		String s2 = new String("PANKAJ");
		System.out.println(s1 == s2);// false

		// scenario 2
		/*
		 * It will print false because we are using new operator to create
		 * String, so it will be created in the heap memory and both s1, s2 will
		 * have different reference. If we create them using double quotes, then
		 * they will be part of string pool and it will print true.
		 */
		
		// scenario 1
		String s3 = new String("abc");
		String s4 = new String("abc");
		System.out.println(s3 == s4); // false
		System.out.println(s4.equals(s3));// true

		// Scenario2 - 2 obj with same reference
		String s5 = "abc";
		String s6 = "abc";
		System.out.println(s5 == s6);// true
		System.out.println(s5.equals(s6));// true

		// Scenario3
		String s9 = "abc";
		StringBuffer s10 = new StringBuffer(s9); // this is StringBuffer
		// System.out.println(s9 == s10); //incompatible
		System.out.println(s9.equals(s10)); // false

		// Scenario4
		System.out.println(s3 == s5);// false checking reference
		System.out.println(s5.equals(s3));// true checking content
	

		// asked in CTS on 24th FEB
		Employee e1 = new Employee(101, "vinod");
		Employee e2 = new Employee(101, "vinod");
		System.out.println("Object Testing \n");
		System.out.println(e1 == e2); // false bcz its checking reference
		System.out.println(e1.hashCode() + " and " + e2.hashCode());
		System.out.println(e1.equals(e2)); // true if we override equals method
											// otherwise false default equals
											// called

		// scenario 4
		String s11 = "abc";
		String s12 = new String("abc");
		System.out.println(s11 == s12);//false
		s12 = s12.intern();
		System.out.println("intern func return reference from heap");
		System.out.println(s11 == s12);//true
	}

}
