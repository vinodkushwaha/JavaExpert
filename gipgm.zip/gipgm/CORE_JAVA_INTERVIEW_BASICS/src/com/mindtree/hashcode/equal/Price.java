package com.mindtree.hashcode.equal;

//don't use prpoperty whch changed the state of the obje
// use this.get method to avoid Lazy loading other wise we will get null
public class Price {
	private String item; // equal method to compare
	private int price;

	public Price(String itm, int pr) {
		this.item = itm;
		this.price = pr;
	}
	
@Override
	public int hashCode() {
		System.out.println("In hashcode which called before equal method");
		int hashcode = 0;
		hashcode = price * 20;
		hashcode += item.hashCode();
		return hashcode;
	}

@Override
	public boolean equals(Object obj) {
		System.out.println("In equals");
		//we should not use Obj== this bcz String also not use this
		//corrected below
		if ( obj != null && obj instanceof Price) {
			Price pp = (Price) obj;
			return (pp.getItem().equals(this.getItem()) && pp.getPrice() == this.getPrice());
		} else {
			return false;
		}
	}

	public String getItem() {
		return item;
	}

	public int getPrice() {
		return price;
	}


	public String toString() {
		return "item: " + item + "� price: " + price;
	}
}