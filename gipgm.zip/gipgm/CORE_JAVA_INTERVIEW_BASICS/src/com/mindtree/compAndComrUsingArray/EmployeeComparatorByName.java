package com.mindtree.compAndComrUsingArray;

import java.util.Comparator;

public class EmployeeComparatorByName implements Comparator<Employee> {
	/**
	 * Comparator to sort employees list or array in order of Name
	 */
    public int compare(Employee e1, Employee e2) {
        return e1.getName().compareTo(e2.getName());
    }

}

