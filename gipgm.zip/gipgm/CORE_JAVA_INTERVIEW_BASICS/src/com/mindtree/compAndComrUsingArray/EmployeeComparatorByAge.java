package com.mindtree.compAndComrUsingArray;

import java.util.Comparator;

public class EmployeeComparatorByAge implements Comparator<Employee> {
	/**
	 * Comparator to sort employees list or array in order of Age
	 */
	 public int compare(Employee e1, Employee e2) {
	        return e1.getAge() - e2.getAge();
	    }

	 

}

