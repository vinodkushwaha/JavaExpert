package com.mindtree.genericParameters;

//What will be the output of the following program?

public class BoundedTypeDemo4 {

	public static void main(String args[]) {
		BoundedType4<Wishes> obj = new BoundedType4<Wishes>(new Wishes());
		obj.print();
	}
}

class BoundedType4<T extends Hi & Hello> {

	T obj;

	BoundedType4(T obj) {
		this.obj = obj;
	}

	void print() {
		obj.print();
		obj.sayHello();
	}
}
/*
 *compiler issue:;:: can't extend interface
class Wishes extends Hello implements Hi
{
    public void print() {
        System.out.print("Hi");
    }
}*/

class Wishes implements Hello, Hi {
	public void print() {
		System.out.print("Hi...");
	}

	public void sayHello() {
		System.out.print("Hello...");
	}
}

interface Hi {
	void print();
}

interface Hello {
	void sayHello();
}
//Hi...Hello...