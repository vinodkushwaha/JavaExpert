package com.mindtree.genericParameters;

//What will be the output?

public class MinDemo {
    public static void main(String args[])
    {
    	//public final class Integer extends Number implements Comparable<Integer> {
        Integer[] integerArray ={10, 1, 5, 7};
        Myclass<Integer> integers = new Myclass<Integer>(integerArray);
        System.out.println(integers.min());
    }
}
interface Min<T>
{
    T min();
}
class Myclass<T extends Comparable<T>> implements Min<T>
{
    T[] values;
    Myclass(T[] values)
    {
        this.values = values;
    }
    
    public T min() {
        T min = values[0];
        for (int i = 1; i < values.length; i++)
        {
            if(values[i].compareTo(min)< 0)
            {
                min = values[i];
            }
        }
        return min;
    }
}
