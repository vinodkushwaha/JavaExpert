package com.mindtree.genericParameters;

//What will be the output of the following program?

public class GenericsWildCardDemo1 {
    public static void main(String args[])
    {
        Number[] ob =  {1.2, 2.2, 3.2, 4.2, 5.2};
        StoreNumbers<Number> obj = new StoreNumbers<Number>(ob);
        print(obj);
    }
    static void print(StoreNumbers<?> c)
    {
    	System.out.println(c.obj.length);
        for(int i = 0; i < c.obj.length; i++)
        {
            System.out.print(c.obj[i] + " ");
        }
    }
}

class StoreNumbers<T extends Number>
{
    T[] obj;
    StoreNumbers(T[] obj) {
        this.obj = obj;
    }
}