package com.mindtree.strings;
//Java program to Reverse a String using swapping
//of variables

//Class of ReverseString
class ReverseString
{
 public static void main(String[] args)
 {
     String input = "Geeks For Geeks";
     char[] temparray = input.toCharArray();
     int left=0;
     int right = temparray.length-1;
     
  while(left < right){
	  // Swap values of left and right
      char temp = temparray[left];
      temparray[left] = temparray[right];
      temparray[right]=temp;
      left++;
      right--;
  }
    
     for (char c : temparray)
         System.out.print(c);
     System.out.println();
 }
}
