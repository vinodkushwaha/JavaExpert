package com.mindtree.array;

import java.util.PriorityQueue;

public class KthSmallestElementInArray {

	public static int find(int [] A, int k){
		//Priority queue stored element in ascending order
		PriorityQueue<Integer> pq = new PriorityQueue<Integer>();
		for(int i=0;i<A.length;i++){
			pq.offer(A[i]); //Inserts the specified element into this priority queue.
		}
		System.out.println("Elecment in priority Queue :" + pq);
		int n = -1;
		while(k>0){
			n = pq.poll();//Retrieves and removes the head of this queue, or returns null if this queue is empty.
			System.out.println("valuse: " + n);
			k--;
		}
		return n;
	}
	public static void main(String[] args) {
		int[] A = { 1, 2, 10, 20, 40, 32, 44, 51, 6 };
		int k = 4;
		System.out.println("4th smallest element:" + find(A,4));

	}

}

