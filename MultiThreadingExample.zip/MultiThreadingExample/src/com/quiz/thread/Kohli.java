package com.quiz.thread;

//What is the output of the following program?

public class Kohli {
	public static void main(String... n) {
		Resource r1 = new Resource("Res 1");
		Resource r2 = new Resource("Res 2");
		DeadLockDemo demo1 = new DeadLockDemo(r1, r2);
		DeadLockDemo demo2 = new DeadLockDemo(r2, r1);
		demo2.start();
		demo1.start();
	}
}

class DeadLockDemo extends Thread {
	Resource resource1;
	private final Resource resource2;

	public DeadLockDemo(Resource resource1, Resource resource2) {
		this.resource1 = resource1;
		this.resource2 = resource2;
	}

	public void run() {
		try {
			resource1.finalize();
			resource2.finalize();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		synchronized (resource1) {
			System.out.println(resource1.getResourceName() + " ");
		}
		resource1 = null;
		synchronized (resource2) {
			System.out.println(resource2.getResourceName() + " ");
		}
	}
}

class Resource extends Object {
	private final String resourceName;

	public Resource(String resourceName) {
		this.resourceName = resourceName;
	}

	public String getResourceName() {
		return resourceName;
	}

	protected void finalize() throws Throwable {
		super.finalize();
	}
}
