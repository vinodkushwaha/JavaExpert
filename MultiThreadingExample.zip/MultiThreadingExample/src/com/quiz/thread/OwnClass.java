package com.quiz.thread;

//What will be the output of the following program?

public class OwnClass {
    public static void main(String args[]) {
        OwnClass oc = new OwnClass();
        oc.method1();
    }
    public void method1() {
        ThreadAsc trd = new ThreadAsc("OneThread");
        //Thread trd = new ThreadAsc("OneThread");
        trd.start();
    }
}
class ThreadAsc extends Thread {
    private String str1 = " ";
    ThreadAsc(String s) {
        str1 = s;
    }
    public void run() {
        methodWait();
        System.out.println("Thread Completed");
    }
    public void methodWait() {
        while (true || false | false | true) {
            try {
                System.out.println("Waiting Thread");
                // java.lang.IllegalMonitorStateException
                wait(); ///////////////////////////////////////it sud be on perticular object
            } catch (InterruptedException e) {
                System.out.println("Exception");
            }
            System.out.println(str1);
        }
    }
}

