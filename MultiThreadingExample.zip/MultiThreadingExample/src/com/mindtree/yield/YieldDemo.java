package com.mindtree.yield;

public class YieldDemo {
	public static void main(String[]args)
{
		System.out.println(Thread.currentThread().getPriority());
    MyThread t = new MyThread();
    t.setName("child Thread");
    t.start(); //there is no guarantee that it will be in running state the moment it starts.

    for (int i=0; i<5; i++)
    {
    	 Thread.yield();// Control passes to Child thread while pausing main thread execution
        
    	 //t.yield();// Control passes to Main thread

        // After execution of child Thread
        // main thread takes over
        System.out.println(Thread.currentThread().getName()
                            + " in control ");
    }
}
}

/*op:
	child Thread in control
	child Thread in control
	child Thread in control
	child Thread in control
	child Thread in control
	main in control 
	main in control 
	main in control 
	main in control 
	main in control 

	or
	main in control 
	child Thread in control
	child Thread in control
	child Thread in control
	child Thread in control
	child Thread in control
	main in control 
	main in control 
	main in control 
	main in control */
	
