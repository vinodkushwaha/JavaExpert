package com.mindtree.customizeThreadPool;

public class Task implements Runnable {
	private int num;

	public Task(int n) {
		num = n;
	}

	public void run() {
		  System.out.println(Thread.currentThread().getName()+" Start. Command = "+ num);
	        try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	        System.out.println(Thread.currentThread().getName()+" End.");
	}
}
