package com.mindtree.customizeThreadPool;

public class Main {
	public static void main(String[] args) {
		ThreadPool pool = new ThreadPool(3);
		//at this point all the threads started and ready to take task
		
		for (int i = 0; i < 5; i++) {
			Task task = new Task(i);
			pool.execute(task);
		}
	}
}
