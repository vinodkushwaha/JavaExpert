package com.mindtree.customizeThreadPool;

import java.util.concurrent.LinkedBlockingQueue;

class PoolWorker extends Thread {
	LinkedBlockingQueue<Runnable> queue;

	public PoolWorker(LinkedBlockingQueue<Runnable> q) {
		this.queue = q;
	}

	public void run() {
		Runnable task;
		// infinite loop
		while (true) {
			synchronized (queue) {
						if (queue.isEmpty()) {
							try {
								queue.wait();
							} catch (InterruptedException e) {
								System.out
										.println("An error occurred while queue is waiting: "
												+ e.getMessage());
							}
						}
				task = queue.poll();
			}

			// If we don't catch RuntimeException,
			// the pool could leak threads
			try {

				task.run();
			} catch (RuntimeException e) {
				System.out
						.println("Thread pool is interrupted due to an issue: "
								+ e.getMessage());
			}
		}
	}
}
