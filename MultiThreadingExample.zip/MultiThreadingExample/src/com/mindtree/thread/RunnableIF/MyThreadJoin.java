package com.mindtree.thread.RunnableIF;

import java.util.ArrayList;
import java.util.List;

public class MyThreadJoin {

	public static List<String> names = new ArrayList<String>();

	public static void main(String a[]) {
		List<SampleThread> list = new ArrayList<SampleThread>();
		for (int i = 0; i < 10; i++) {
			SampleThread s = new SampleThread();
			list.add(s); //adding all the thread in list
			s.start();
		}
		for (SampleThread st : list) {
			try {
				st.join();
			} catch (Exception ex) {
			}
		}
		for (String sampleThread : names) {
			System.out.println("\n" +sampleThread + "\n");
		}
		
		System.out.println("\n" +names + "\n");
	}
}

class SampleThread extends Thread {

	public void run() {
		for (int i = 0; i < 10; i++) {
			try {
				Thread.sleep(2);
			} catch (Exception ex) {
			}
		}
		System.out.println("Thread is Alive::" + Thread.currentThread().isAlive());
		MyThreadJoin.names.add(Thread.currentThread().getName());
	}
}
