package com.multi.thread;

import java.util.concurrent.atomic.AtomicInteger;

/*Write a java program to print 3 threads alternate values in sequence.  

 Expected result: 
 Thread[Thread1,5,main] 1
 Thread[Thread2,5,main] 2
 Thread[Thread3,5,main] 3
 Thread[Thread1,5,main] 4
 Thread[Thread2,5,main] 5
 Thread[Thread3,5,main] 6
 Thread[Thread1,5,main] 7
 Thread[Thread2,5,main] 8
 Thread[Thread3,5,main] 9*/
public class ThreeThreadsOrderedLockLess {

	AtomicInteger sharedOutput = new AtomicInteger(0);
	private Object object = new Object();

	public static void main(String args[]) throws InterruptedException {
		ThreeThreadsOrderedLockLess t = new ThreeThreadsOrderedLockLess();
		MyThread t1 = t.new MyThread(0);
		MyThread t2 = t.new MyThread(1);
		MyThread t3 = t.new MyThread(2);

		Thread ts1 = new Thread(t1);
		Thread ts2 = new Thread(t2);
		Thread ts3 = new Thread(t3);
		ts1.setName("Thread1");
		ts2.setName("Thread2");
		ts3.setName("Thread3");
		ts1.start();
		ts2.start();
		ts3.start();

	}

	private class MyThread implements Runnable {
		private final int threadPosition;

		public MyThread(int threadPosition) {
			super();
			this.threadPosition = threadPosition;
		}

		@Override
		public void run() {
			while (sharedOutput.get() < 99) {

				synchronized (object) {

					if (sharedOutput.get() % 3 == this.threadPosition) {

						if (sharedOutput.get() < 99)
							System.out.println(Thread.currentThread() + "  "+ sharedOutput.incrementAndGet());
					}
				}
			}
		}
	}
}
