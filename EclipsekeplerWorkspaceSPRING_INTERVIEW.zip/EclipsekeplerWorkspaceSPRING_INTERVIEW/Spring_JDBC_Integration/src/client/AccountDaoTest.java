/**
 * 
 */
package client;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mindtree.dao.AccountDao;
import com.mindtree.entity.Account;
import com.mindtree.exception.DaoException;

/**
 * @author Banu Prakash � 2011 MindTree Limited
 * 
 */
public class AccountDaoTest {
	static Logger logger = Logger.getLogger(AccountDaoTest.class);

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");

		AccountDao accountDao = context.getBean("accountDao", AccountDao.class);
		Account rahulAccount = new Account("SB500", "Rahul Prakash", 45000.55);
		Account gavinAccount = new Account("SB8920", "Gavin king", 6000.33);
		try {
			System.out.println("try");
			accountDao.createAccount(rahulAccount);
		} catch (DaoException e) {
			System.out.println("try" + e.getMessage());
			logger.debug(e);
		}
		try {
			accountDao.createAccount(gavinAccount);
		} catch (DaoException e) {
			logger.debug(e);
		}

		List<Account> accounts;
		try {
			accounts = accountDao.getAllAccounts();
			for (Account account : accounts) {
				System.out.println(account);
			}
		} catch (DaoException e) {
			logger.debug(e);
		}

	}

}
