/**
 * 
 */
package com.mindtree.service;

import com.mindtree.exception.ApplicationException;

/**
 * @author Banu Prakash � 2011 MindTree Limited
 *
 */
public interface TransferService {
	
	/**
	 * @param fromAccount
	 * @param destAccount
	 * @param amount
	 * @throws ApplicationException 
	 */
	void transferFunds(String fromAccount, String destAccount, double amount) throws ApplicationException;

}
