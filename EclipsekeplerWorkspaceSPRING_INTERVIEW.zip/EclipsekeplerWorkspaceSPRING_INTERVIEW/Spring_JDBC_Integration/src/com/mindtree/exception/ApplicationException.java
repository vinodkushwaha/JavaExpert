/**
 * 
 */
package com.mindtree.exception;
/**
 * @author Banu Prakash � 2011 MindTree Limited
 *
 */
public class ApplicationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2180348972548317896L;

	/**
	 * 
	 */
	public ApplicationException() {
		super();
 	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public ApplicationException(String msg, Throwable ex) {
		super(msg, ex);
 	}

	/**
	 * @param arg0
	 */
	public ApplicationException(String msg) {
		super(msg);
 	}

	/**
	 * @param arg0
	 */
	public ApplicationException(Throwable ex) {
		super(ex);
 	}
	
}
