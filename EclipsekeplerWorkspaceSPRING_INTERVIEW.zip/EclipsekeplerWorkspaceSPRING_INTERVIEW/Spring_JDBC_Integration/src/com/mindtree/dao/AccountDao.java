package com.mindtree.dao;

import java.util.List;

import com.mindtree.entity.Account;
import com.mindtree.exception.DaoException;

/**
 * @author Banu Prakash � 2011 MindTree Limited
 *
 */
public interface AccountDao {
	public void createAccount(Account account) throws DaoException;
	public Account getAccount(String accountNumber) throws DaoException;
	public List<Account> getAllAccounts() throws DaoException;
	public void updateAccount(Account account) throws DaoException;
}
