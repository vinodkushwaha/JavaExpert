package com.mindtree.service;

import com.mindtree.dao.AccountDao;
import com.mindtree.entity.Account;

/**
 * @author Banu Prakash � 2011 MindTree Limited
 * 
 */
public class TransferServiceImpl implements TransferService {

	private AccountDao accountDao;

	/**
	 * @param accountDao
	 */
	public TransferServiceImpl(AccountDao accountDao) {
		this.accountDao = accountDao;
	}

	/**
	 * @param accountDao
	 *            the accountDao to set
	 */
	public void setAccountDao(AccountDao accountDao) {
		this.accountDao = accountDao;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.mindtree.service.TransferService#transferFunds(java.lang.String,
	 * java.lang.String, double)
	 */
	@Override
	public void transferFunds(String fromAccount, String destAccount,
			double amount) {
		Account srcAcct = accountDao.getAccount(fromAccount);
		Account destAcct = accountDao.getAccount(destAccount);

		srcAcct.debit(amount);
		destAcct.credit(amount);

		accountDao.updateAccount(srcAcct);
		accountDao.updateAccount(destAcct);

	}

}
