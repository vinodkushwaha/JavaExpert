/**
 * 
 */
package com.mindtree.service;

/**
 * @author Banu Prakash � 2011 MindTree Limited
 *
 */
public interface TransferService {
	
	/**
	 * @param fromAccount
	 * @param destAccount
	 * @param amount
	 */
	void transferFunds(String fromAccount, String destAccount, double amount);

}
