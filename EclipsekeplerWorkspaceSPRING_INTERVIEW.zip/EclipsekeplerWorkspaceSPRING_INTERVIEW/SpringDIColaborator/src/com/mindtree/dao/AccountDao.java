/**
 * 
 */
package com.mindtree.dao;

import java.util.List;

import com.mindtree.entity.Account;

/**
 * @author Banu Prakash � 2011 MindTree Limited
 *
 */
public interface AccountDao {
	public void createAccount(Account account);
	public Account getAccount(String accountNumber);
	public List<Account> getAllAccounts();
	public void updateAccount(Account account);
}
