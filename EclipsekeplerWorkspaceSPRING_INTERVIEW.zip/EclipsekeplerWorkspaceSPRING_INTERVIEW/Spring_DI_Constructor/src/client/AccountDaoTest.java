/**
 * 
 */
package client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mindtree.entity.Account;

/**
 * @author Banu Prakash � 2011 MindTree Limited
 *
 */
public class AccountDaoTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	  ApplicationContext context  = 
			  	new ClassPathXmlApplicationContext("beans.xml");
	  
	  Account rahulAcc = 
			  context.getBean("rahulAccount", Account.class);
	 System.out.println(rahulAcc.getAccountNumber() 
			 		+"," + rahulAcc.getAccountOwner() 
			 		+"," + rahulAcc.getBalance());
	}

}
