package com.mindtree.MultipleInheritance;

public interface A {
	 default void display(){
		 System.out.println("hjhj");
	 };
	 }

