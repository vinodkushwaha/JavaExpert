package com.mindtree.MultipleInheritance;

public class D implements B,C {

	public void display() { 
	    B.super.display();       
	  }

}
