package com.mindtree.lamdaExpression;



public interface StateChangeListener {

    public void onStateChange(State oldState, State newState);

}

