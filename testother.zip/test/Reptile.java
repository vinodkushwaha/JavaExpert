package com.ubs.test;

public class Reptile extends Animal {
	
	{
		System.out.println("Reptile Initialize block");
	}
	
	static {
		System.out.println("Reptile static block");
	}

	Reptile() {
		System.out.println("Reptile Constructor");
	}
}
