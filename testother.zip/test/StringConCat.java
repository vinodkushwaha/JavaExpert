package com.ubs.test;

public class StringConCat {

	public static void main(String[] args) {
		String message = "Good Morning";
		message.concat(" Sir");

		String msg = (message.length() > 12) ? "Message is too long" : "Ok Message";
		System.out.println(msg);
	}

}
