package com.ubs.test;

public interface AnimalInterface {

	/// work fine
	int numberOfEyes = 2;

	// work fine
	public static final int num = 5;

	// work fine
	public void canSwim();

	// work fine
	public default void defaulteat(String food) {
		System.out.println("I ate :: " + food);

	}

	// work fine
	public static void staticeat(String food) {
		System.out.println("I ate :: " + food);

	}

	// ================Compiler Error============
	// This method requires a body instead of a semicolon
	public static void icanSwim();

	// Abstract methods do not specify a body
	public void eat(String food) {
		System.out.println("I ate :: " + food);

	}
}
