package com.ubs.test;

public class OperatorTest {
/*	
 * & : Bitwise operator
   && : logical operator 
 * int i=5;
	if(i<3 & i++ < 10)
	{
	 //perform action
	}

	Now in this case 
	First expression is i<3
	Second expression is i++ < 10

	when & is used it will evaluate both the expressions regardless of 
	the fact that it finds first expression as FALSE and only then will 
	it give an answer.

	Whereas if && was used in place of & , after it had evaluated first 
	expression and had found result of first expression as FALSE, it would not 
	have evaluated second expression. Thus saving time.

	FYI... && is also called as counterpart of & and the evaluation it does
is called short-circuit evaluation.*/
	public static void main(String [] args) {
		int x= 0;
		int y=0;
		boolean z = false;
		int count =0;
		if(z=true || y==1) {
			count = count +1;
		}
		if(z^false) {
			count =count +1;
		}
		if(++x > 0 & y++ > 0) {
			count = count + 1;
		}
		System.out.println(count);
	}
}
