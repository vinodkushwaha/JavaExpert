package com.ubs.test;

public class ThreadTest1 extends Thread {
	
	private String sTName ="";
	ThreadTest1(String s){
		this.sTName =s;
		
	}
	
	public void run() {
		for(int i=0; i< 2; i++) {
			try {
				sleep(2000);
			}
			catch(InterruptedException e) {
				yield();
				System.out.println(sTName +  " ");
			}
		}
	}

}
