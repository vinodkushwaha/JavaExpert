package com.ubs.test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class ListComapre {

	public static void main(String[] args) {
		List<String> lists = Arrays.asList("Burger", "Pizza", "Dnout", "Burger");

	Set<String> s1 = new HashSet<>(lists);
	Set<String> s2 = new TreeSet<>(lists);
	System.out.println(s1 + "\n"+s2);
	System.out.println(s1.equals(s2));
	}

}
