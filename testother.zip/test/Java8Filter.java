package com.ubs.test;

import java.util.Arrays;

public class Java8Filter {

	public static void main(String[] args) {
		Arrays.stream(new int[] { 1, 2, 3, 4 }).map(n -> 3 * n + 1).filter(i -> i > 10).average()
				.ifPresent(System.out::println);
	}

}
//13.0